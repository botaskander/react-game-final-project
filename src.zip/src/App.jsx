import React from 'react'
import GameContainer from './components/GameContainer.jsx'

const App = () => {
  return <GameContainer />
}

export default App
